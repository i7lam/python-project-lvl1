#!/usr/bin/python3.9
def fp(arg):
    print(arg)
def main():
    fp('Welcome to the Brain games!')
if __name__ == '__main__':
    main()
