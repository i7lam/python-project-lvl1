#!/usr/bin/python3.9
from brain_games.cli import welcome_user
def fp(arg):
    print(arg)
def main():
    fp('Welcome to the Brain games!')
    welcome_user()
if __name__ == '__main__':
    main()
